import java.util.Scanner;

import static Tools.Utility.menu;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] opzioni = {"--SCELTA PARTITA--", "1-BASE", "2-AVANZATA"};

        switch (menu(opzioni, sc)) {
            case 1: {
                giocaPartita(new Partita(new Giocatore("Giocatore 1", 6), new Giocatore("Giocatore 2", 6), 5, 1));
                break;
            }
            case 2: {
                giocaPartita(new Partita(new Giocatore("Giocatore 1", 6), new Giocatore("Giocatore 2", 6), 5, 2));
                break;
            }
        }
    }

    public static void giocaPartita(Partita partita) {
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println(partita.statoPartita());
            System.out.println(partita.round());
        } while (partita.statoPartita().equals("Partita in corso"));

        System.out.println(partita.statoPartita());
        System.out.println("Vincitore: " + partita.vincitore());
    }
}
